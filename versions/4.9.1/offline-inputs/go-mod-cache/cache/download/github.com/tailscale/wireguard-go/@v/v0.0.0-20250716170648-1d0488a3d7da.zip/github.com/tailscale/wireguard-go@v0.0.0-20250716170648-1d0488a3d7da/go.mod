module github.com/tailscale/wireguard-go

go 1.20

require (
	golang.org/x/crypto v0.13.0
	golang.org/x/net v0.15.0
	golang.org/x/sys v0.12.0
	golang.zx2c4.com/wintun v0.0.0-20230126152724-0fa3db229ce2
	gvisor.dev/gvisor v0.0.0-20230927004350-cbd86285d259
)

require (
	github.com/google/btree v1.0.1 // indirect
	golang.org/x/time v0.0.0-20220210224613-90d013bbcef8 // indirect
)
